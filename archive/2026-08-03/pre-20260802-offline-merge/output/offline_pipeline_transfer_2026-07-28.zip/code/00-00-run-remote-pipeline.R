required_packages <- c(
  "haven", "dplyr", "data.table", "purrr", "readr", "stringr",
  "tidyr", "tibble"
)
missing_packages <- required_packages[
  !vapply(required_packages, requireNamespace, logical(1), quietly = TRUE)
]
if (length(missing_packages) > 0L) {
  stop(
    "Missing required R packages: ",
    paste(missing_packages, collapse = ", "),
    ". Install them before running the offline pipeline."
  )
}

source("code/01-00-load-packages.R")

args <- commandArgs(trailingOnly = TRUE)
raw_data_dir <- if (length(args) >= 1) {
  args[[1]]
} else {
  Sys.getenv("RAW_DATA_DIR", unset = "data/raw_data")
}
Sys.setenv(RAW_DATA_DIR = raw_data_dir)

all_survey_files <- list.files(
  raw_data_dir,
  pattern = "^data\\d+(?:_\\d+)?\\.(?:dta|sav)$",
  recursive = TRUE,
  full.names = TRUE,
  ignore.case = TRUE
)
normalized_survey_paths <- stringr::str_replace_all(all_survey_files, "\\\\", "/")
all_survey_files <- all_survey_files[
  !stringr::str_detect(normalized_survey_paths, "(^|/)archive(/|$)")
]
if (length(all_survey_files) == 0) {
  stop(
    "No data*.dta or data*.sav files found below: ", raw_data_dir, "\n",
    "00-00 is the offline full-pipeline runner, not an installation script. ",
    "Run it only where the seven raw files are available, for example:\n",
    "Rscript code/00-00-run-remote-pipeline.R \"/absolute/path/to/raw_data\"\n",
    "For local checks without raw data, run 00-01 and 00-02 separately."
  )
}

required_file_stems <- c(
  "data91_1", "data91_2", "data95", "data99", "data103", "data106", "data110"
)
all_file_stems <- stringr::str_to_lower(
  tools::file_path_sans_ext(basename(all_survey_files))
)
available_file_stems <- all_file_stems[all_file_stems %in% required_file_stems]
missing_file_stems <- setdiff(required_file_stems, available_file_stems)
if (length(missing_file_stems) > 0L) {
  stop(
    "Refusing to overwrite cross-year outputs with a partial raw-data set. ",
    "Missing survey tags: ", paste(missing_file_stems, collapse = ", "),
    " (each may use .dta or .sav)"
  )
}
duplicate_file_stems <- names(which(table(available_file_stems) > 1L))
if (length(duplicate_file_stems) > 0L) {
  stop(
    "Each raw survey file must appear exactly once below RAW_DATA_DIR. Duplicates: ",
    paste(duplicate_file_stems, collapse = ", ")
  )
}
ignored_file_stems <- setdiff(all_file_stems, required_file_stems)
if (length(ignored_file_stems) > 0L) {
  message(
    "Ignoring non-pipeline survey files: ",
    paste(unique(ignored_file_stems), collapse = ", "),
    ". Files below an archive folder are excluded automatically."
  )
}

source("code/00-01-validate-offline-inputs.R", local = new.env(parent = globalenv()))

message("[1/10] Import raw survey files")
source("code/02-00-import-cross-year-survey-data.R", local = new.env(parent = globalenv()))

message("[2/10] Build survey metadata")
source("code/03-00-make-year-survey-meta.R", local = new.env(parent = globalenv()))

scripts <- c(
  "code/03-01-make-basic-info-from-02.R",
  "code/03-02-make-demographic-data-from-02.R",
  "code/03-03-make-family-data-from-02.R",
  "code/03-04-make-income-expense-data-from-02.R",
  "code/04-01-aggregate-cross-year-data.R",
  "code/05-01-summary-statistics.R",
  "code/05-02-income-expenditure-recode-summary.R",
  "code/05-99-validate-offline-pipeline.R"
)

for (i in seq_along(scripts)) {
  message("[", i + 2L, "/10] ", scripts[[i]])
  source(scripts[[i]], local = new.env(parent = globalenv()))
}

expected_years <- sort(unique(readr::read_csv(
  "data/processed_data/02_metadata/imported_survey_index.csv",
  show_col_types = FALSE
)$data_year))
combined <- readRDS("data/processed_data/04_analysis_ready/cross_year_combined_data.rds")
missing_years <- setdiff(expected_years, sort(unique(combined$DATA_Y)))
if (length(missing_years) > 0) {
  stop("Combined output is missing imported survey years: ", paste(missing_years, collapse = ", "))
}

message("Remote pipeline completed for years: ", paste(expected_years, collapse = ", "))
